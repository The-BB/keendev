<?php
$title='SSH client on Zyxel Keenetic';
$header='Команды SSH';
include('header.php');
$serveradr=$_SERVER["SERVER_NAME"];
$filename = './history/ssh.txt';
if ($_GET['history'] == 'clean')
{
	unlink($filename);
}
$sshcmd = $_POST['sshcom'];
if ($sshcmd != '')
{
	$fp = fopen($filename, 'a');
	$history = $sshcmd."\r\n";
	$write = fwrite($fp, $history);
	fclose($fp);
	if (strstr($sshcmd, 'service '))
	{
		$sshcmd = str_replace('service ', '/opt/etc/init.d/', $sshcmd);
		$sshresult = shell_exec($sshcmd);
	}
	elseif (strstr($sshcmd, 'top'))
	{
		$sshcmd = '/opt/bin/top -b -n1';
		$sshresult = shell_exec($sshcmd);
	}
	else
	{
		$sshresult = shell_exec($sshcmd);
	}
	if (!$sshresult)
	{
		$sshresult = 'Неизвестная команда или вывод данных невозможен';
	}
	$sshresult = "keenetic# ".$_POST['sshcom']."\n************************\n".str_replace("\n","\n\n",$sshresult);
	echo "<textarea class='shell' name='result' cols='95' rows='30'>".$sshresult."</textarea>";
}
else
{
	if (is_file($filename))
	{
    		$inphist = array_reverse(file($filename));
    		$inphist = implode('', array_slice($inphist,0,100));
    		$inphist = "История команд ssh:\n\n".$inphist;
		echo "<textarea class='shell' name='result' cols='95' rows='30'>".$inphist."</textarea>";
	}
}

echo "<form method='post' action='../addons/ssh.php'>
<p>
<input type='text' name='sshcom' size='80'><input type='submit' name='submit' value='Выполнить'>
</p>
</form>";
if (is_file($filename))
{
	echo "<table border='0'><tr><td class='value'><a href='../addons/ssh.php?history=clean'>Очистить историю</a></td></tr></table>";
}
include('footer.php');
?>